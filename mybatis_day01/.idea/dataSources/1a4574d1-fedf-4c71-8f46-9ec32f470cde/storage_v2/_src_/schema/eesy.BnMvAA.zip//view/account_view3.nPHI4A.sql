create view account_view3 as
  select
    `eesy`.`account`.`id`            AS `id`,
    `eesy`.`account`.`name`          AS `name`,
    `eesy`.`account`.`money`         AS `money`,
    `eesy`.`account`.`ACCOUNT_PHONE` AS `ACCOUNT_PHONE`,
    `eesy`.`account`.`CREATE_DATE`   AS `CREATE_DATE`
  from `eesy`.`account`;

